## Config

All config files must be in this folder, if there is no option to set the folder directly, it has to be hardlinked.